<!-- header section starts  -->
    <header class="header">

        <a href="<?php echo e(url('/')); ?>" class="logo"> <img src="<?php echo e(asset('images/Palestine.png')); ?>" alt="Palestine" width="40">فلسطين</a>
        <nav class="navbar">
            <div id="nav-close" class="fas fa-times"></div>
            <a href="<?php echo e(url('/')); ?>">الرئيسية</a>
            <a href="<?php echo e(route('map')); ?>">الخريطة</a>
            <a href="<?php echo e(route('blogs')); ?>">أخبارنا</a>
            <a href="<?php echo e(route('products')); ?>">المنتجات</a>
            <a href="<?php echo e(route('contact')); ?>">اتصل بنا</a>
        </nav>
        <?php if(auth()->guard()->check()): ?>
            <div class="dropdown">
            <button class="btn btn-outline-success dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                <?php echo e(auth()->user()->name); ?>

            </button>
            <ul class="dropdown-menu">
                <?php
                    $favs_count = App\Models\Fav::where('user_id', auth()->user()->id)->count();
                ?>
                <li class="like">
                    <a class="dropdown-item" href="<?php echo e(route('city.fav')); ?>">
                        <i class="fa fa-heart"></i>
                        <span>مفضلاتك</span>
                        <p class="count"><?php echo e($favs_count); ?></p>
                    </a>
                </li>
                <div class="dropdown-divider"></div>
                <li>
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('frm-logout').submit();">
                        <i class="fa-solid fa-right-from-bracket"></i>
                        <span class="align-middle">تسجيل الخروج</span>
                    </a>    
                    <form id="frm-logout" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo e(csrf_field()); ?>

                    </form>
                </li>
            </ul>
            </div>
        <?php endif; ?>

        <div class="icons ml-3">
            <div id="menu-btn" class="fas fa-bars"></div>
            <!--<a href="#" class="fas fa-shopping-cart"></a>-->
            <div id="search-btn" class="fas fa-search"></div>
        </div>

    </header>
<div class="search-form">
    <div id="close-search" class="fas fa-times"></div>
    <form action="">
        <input type="search" name="" placeholder="search here..." id="search-box">
        <label for="search-box" class="fas fa-search"></label>
    </form>
</div>
<!-- ------scroller to top -->

<a href="#top" class="to-top">
  <i class="fas fa-chevron-up"></i>
</a>

<!-- header section ends -->  <?php /**PATH C:\laragon\www\palastine\resources\views/layouts/header.blade.php ENDPATH**/ ?>