<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" dir="rtl">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/all.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/bootstrap.rtl.min.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('js/jquery-3.5.1.min.js')); ?>"></script>  
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>  
    <script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(asset('css/toastr.min.css')); ?>"/>
    <script src="<?php echo e(asset('js/toastr.min.js')); ?>"></script>  
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body>
    <?php echo $__env->make('layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div id="app">
        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <!-- Scripts -->
    <?php echo $__env->yieldContent('js'); ?>
</body>
</html>
<?php /**PATH C:\laragon\www\palastine\resources\views/layouts/app.blade.php ENDPATH**/ ?>