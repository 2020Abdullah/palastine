

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('admin.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-0">
        <div class="table-action">
            <h3 class="h3 mb-3">أشهر الأماكن في المدن</h3>
            <a href="<?php echo e(route('admin.place.create')); ?>" class="btn btn-success">إضافة مكان جديد</a>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                         <div class="table-responsive">
                            <table class="table table-bordered">
                                <tr>
                                    <td>المكان</td>
                                    <td>وصف المكان</td>
                                    <td>صورة المكان</td>
                                    <td>المدينة</td>
                                </tr>
                                <?php $__empty_1 = true; $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($place->name); ?></td>
                                        <td><?php echo e($place->info); ?></td>
                                        <td><img src="<?php echo e(asset('images/place/' . $place->image)); ?>" alt="img"></td>
                                        <td><?php echo e($place->city->name); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr class="text-center">
                                        <td colspan="4">لا يوجد مدينة مضافة حتي الآن</td>
                                    </tr>
                                <?php endif; ?>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\palastine\resources\views/admin/place/index.blade.php ENDPATH**/ ?>