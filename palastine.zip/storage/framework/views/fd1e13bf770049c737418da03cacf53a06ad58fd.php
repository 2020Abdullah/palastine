

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('home/css/home.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="post">
    <div class="container text-center">
          <h3 class="heading">اشهر الأماكن في <?php echo e($city->name); ?></h3>
          <hr/>
          <div class="row">
          <?php $__currentLoopData = $city->places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($loop->iteration % 2 == 0): ?>
                <div class="container text-center post lpost">
                    <div class="row">
                        <div class="col">
                            <img src="<?php echo e(asset('images/place/' . $place->image)); ?>" alt="img-1">
                        </div>
                        <div class="col">
                            <h5><?php echo e($place->name); ?></h5>
                            <p><?php echo e($place->info); ?></p>    
                        </div>
                    </div>
                </div>
            <?php else: ?>
                  <div class="container text-center post lpost">
                    <div class="row flex-row-reverse">
                        <div class="col">
                            <img src="<?php echo e(asset('images/place/' . $place->image)); ?>" alt="img-1">
                        </div>
                        <div class="col">
                            <h5><?php echo e($place->name); ?></h5>
                            <p><?php echo e($place->info); ?></p>    
                        </div>
                    </div>
                </div>
            <?php endif; ?>
   
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('home/js/allscript.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\palastine\resources\views/places.blade.php ENDPATH**/ ?>