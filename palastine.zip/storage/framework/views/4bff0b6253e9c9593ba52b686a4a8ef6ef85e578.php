

<?php $__env->startSection('content'); ?>
<div class="fav" style="margin-top: 10rem;">
    <div class="container text-center">
          <h3 class="heading">مدنك المفضلة</h3>
          <hr/>
          <div class="row">
          <?php $__currentLoopData = $favs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="container text-center">
                <div class="row">
                    <div class="col">
                        <img src="<?php echo e(asset('images/city/' . $fav->city->image)); ?>" alt="img-1">
                    </div>
                    <div class="col">
                        <h5><?php echo e($fav->city->name); ?></h5>
                        <p><?php echo e($fav->city->info); ?></p>    
                    </div>
                </div>
            </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('home/js/allscript.js')); ?>" defer></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\palastine\resources\views/fav.blade.php ENDPATH**/ ?>