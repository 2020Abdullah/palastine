

<?php $__env->startSection('sidebar'); ?>
    <?php echo $__env->make('admin.layout.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('admin.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid p-0">
        <h3 class="h3 mb-3">إحصائيات</h3>
        <div class="row text-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h3>عدد المدن</h3>
                        <p class="h2 pt-4"><?php echo e($city_count); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h3>عدد الأماكن</h3>
                        <p class="h2 pt-4"><?php echo e($place_count); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\palastine\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>